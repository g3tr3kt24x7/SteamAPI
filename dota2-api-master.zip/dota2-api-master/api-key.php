<?php

// dota2 api key (you can get_info it here - http://steamcommunity.com/dev/apikey)
define ('API_KEY','**************************');