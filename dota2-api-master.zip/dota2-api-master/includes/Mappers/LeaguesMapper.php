<?php

namespace Dota2Api\Mappers;

abstract class LeaguesMapper
{

}
